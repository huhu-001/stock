"""尾盘选股（14:30）：每天给出 10 只候选股，并用历史数据回测、每日复盘。

模型：短线反转 + 低关注度（依据 2025-04 ~ 2026-09 中证500 实盘数据的因子检验）
  在真实数据中，下列指标越“强”的股票，次日表现越差（三个时段结论一致）：
    当日涨幅、K线实体、偏离20日线、20日涨幅、收盘相对均价、近5日放量、换手、波动率、RSI6
  因此对这 9 个指标在股票池内做横截面排名，取“越弱越好”的平均分作为得分（0~100）。
  过滤：涨跌停（买不到/卖不掉）、ST、成交额最低的 30%。

重要：回测显示该模型只是“略好于/接近股票池平均”，并不能可靠预测次日涨跌；
      旧的“追涨”规则在同样数据上明显跑输。请把结果当作观察名单，而不是买入建议。
"""
from __future__ import annotations

import logging
import sys
from datetime import datetime
from pathlib import Path

import numpy as np
import pandas as pd

from .data import BaseProvider
from .monitor import merge_live_bar
from .screener import _names, _progress, get_spot_safe, resolve_universe
from .timeutil import SESSIONS, is_trading_time, now_cn

log = logging.getLogger(__name__)

DEFAULTS = {
    "universe": "zz500",       # 选股池：zz500 / hs300 / zz1000 / all / watchlist ...
    "top_n": 10,
    "min_amount_pct": 0.3,     # 剔除成交额最低的 30%
    "cost": 0.0015,            # 回测往返交易成本
}

# 反转因子：数值越小越好（得分取反向排名）
FACTORS = {
    "r1": "当日涨幅", "body": "K线实体", "ma20gap": "偏离20日线", "r20": "20日涨幅",
    "vwapgap": "收盘相对均价", "vr20": "5日/60日量比", "turn": "换手率", "vol20": "20日波动率",
    "rsi6": "RSI6",
}


def params(cfg: dict) -> dict:
    p = {**DEFAULTS, **(cfg.get("tail") or {})}
    return {k: p[k] for k in DEFAULTS}   # 忽略旧版配置里已废弃的参数


def limit_pct(code: str) -> float:
    return 0.195 if code.startswith(("300", "301", "688")) else 0.097


def elapsed_fraction(dt: datetime | None = None) -> float:
    """当日已交易时间占全天 240 分钟的比例，用于把盘中成交量折算成全天。"""
    dt = dt or now_cn()
    if not is_trading_time(dt):
        return 1.0
    mins = 0.0
    t = dt.hour * 60 + dt.minute
    for s, e in SESSIONS:
        a, b = s.hour * 60 + s.minute, e.hour * 60 + e.minute
        mins += max(0, min(t, b) - a)
    return max(mins / 240, 0.05)


def stock_features(df: pd.DataFrame, code: str, with_forward: bool = False) -> pd.DataFrame:
    """单只股票逐日特征（最后一行可以是盘中实时K线）。"""
    c, o, h, l, v, a = df["close"], df["open"], df["high"], df["low"], df["volume"], df["amount"]
    f = pd.DataFrame(index=df.index)
    f["code"] = code
    f["close"] = c
    f["r1"] = c.pct_change()
    f["body"] = (c - o) / o
    f["ma20gap"] = c / c.rolling(20).mean() - 1
    f["ma60gap"] = c / c.rolling(60).mean() - 1
    f["r20"] = c / c.shift(20) - 1
    vwap = a / (v * 100)
    vwap = vwap.where((vwap > l * 0.95) & (vwap < h * 1.05))
    f["vwapgap"] = c / vwap - 1
    f["vr20"] = v.rolling(5).mean() / v.rolling(60).mean()
    f["turn"] = df["turnover"] if "turnover" in df else np.nan
    f["vol20"] = f["r1"].rolling(20).std()
    d = c.diff()
    up = d.clip(lower=0).ewm(alpha=1 / 6, adjust=False).mean()
    dn = (-d.clip(upper=0)).ewm(alpha=1 / 6, adjust=False).mean()
    f["rsi6"] = 100 - 100 / (1 + up / dn.replace(0, np.nan))
    f["amt20"] = a.rolling(20).mean()
    f["limit"] = f["r1"].abs() >= limit_pct(code)
    if with_forward:
        f["ret_open"] = o.shift(-1) / c - 1
        f["ret_high"] = h.shift(-1) / c - 1
        f["ret_close"] = c.shift(-1) / c - 1
        f["ret_2d"] = c.shift(-2) / c - 1
    return f


def score_cross_section(feat: pd.DataFrame, p: dict) -> pd.DataFrame:
    """按日期做横截面打分。feat 需含 date 列。返回过滤后的带 score 的数据。"""
    x = feat.reset_index(drop=True).dropna(subset=["r1", "amt20"]).copy()
    x = x[x[list(FACTORS)].notna().sum(axis=1) >= len(FACTORS) - 2]   # 最多允许缺 2 个因子
    x = x[~x["limit"]]
    x = x[x.groupby("date")["amt20"].rank(pct=True) > p["min_amount_pct"]]
    ranks = x.groupby("date")[list(FACTORS)].rank(pct=True)
    x["score"] = ((1 - ranks).mean(axis=1) * 100).round(1)
    return x


def _tags(r: pd.Series) -> str:
    t = []
    if r["r20"] <= -0.08:
        t.append(f"20日回调{r['r20'] * 100:.0f}%")
    if r["ma20gap"] < -0.03:
        t.append("低于20日线")
    if r["vr20"] < 0.8:
        t.append("缩量")
    if r["vol20"] < 0.02:
        t.append("低波动")
    if r["rsi6"] < 30:
        t.append("RSI超卖")
    if r["vwapgap"] < -0.005:
        t.append("尾盘弱于均价")
    if r.get("ma60gap", 0) > 0:
        t.append("仍在60日线上")
    return "、".join(t)


# ----------------------------------------------------------------------------
def pick_live(provider: BaseProvider, cfg: dict, spot: pd.DataFrame | None = None,
              universe: str | None = None):
    """实时尾盘选股，返回 (结果表, {code: 含实时K线的日线})。"""
    p = params(cfg)
    universe = universe or p["universe"]
    if spot is None:
        spot = get_spot_safe(provider)   # 失败时退回用缓存的日线收盘数据
    codes = resolve_universe(provider, cfg, universe, spot)
    names = _names(provider, spot)
    if not any(names.get(c) for c in codes[:5]):
        try:
            idx = provider.index_constituents({"zz500": "000905", "hs300": "000300",
                                               "zz1000": "000852"}.get(universe, "000905"))
            names.update(dict(zip(idx["code"], idx["name"])))
        except Exception:  # noqa: BLE001
            pass
    print(f"  选股池 {universe}: {len(codes)} 只，下载/读取日线…", file=sys.stderr, flush=True)
    hist = provider.daily_batch(codes, max_workers=int(cfg["data"]["max_workers"]),
                                progress=_progress)
    today = pd.Timestamp(now_cn().date())
    el = elapsed_fraction()
    sidx = spot.set_index("code") if spot is not None else None
    rows, live_hist = [], {}
    for code, df in hist.items():
        if len(df) < 80:
            continue
        live = df
        if sidx is not None and code in sidx.index:
            live = merge_live_bar(df, sidx.loc[code], today)
            if el < 1 and live.index[-1] == today:   # 盘中成交量/额/换手折算成全天
                for col in ("volume", "amount", "turnover"):
                    if col in live:
                        live.iloc[-1, live.columns.get_loc(col)] /= el
        live_hist[code] = live
        f = stock_features(live, code)
        last = f.iloc[[-1]].copy()
        rows.append(last)
    if not rows:
        return pd.DataFrame(), {}
    feat = pd.concat(rows)
    feat["date"] = today
    scored = score_cross_section(feat, p).sort_values("score", ascending=False)
    top = scored.head(int(p["top_n"]))
    out = []
    for _, r in top.iterrows():
        code = r["code"]
        out.append({"代码": code, "名称": names.get(code, ""),
                    "现价": round(float(r["close"]), 2), "涨幅%": round(float(r["r1"]) * 100, 2),
                    "得分": r["score"], "20日涨幅%": round(float(r["r20"]) * 100, 1),
                    "距20日线%": round(float(r["ma20gap"]) * 100, 1),
                    "换手%": round(float(r["turn"]), 2) if pd.notna(r["turn"]) else None,
                    "特征": _tags(r)})
    res = pd.DataFrame(out)
    if not res.empty:
        res.insert(0, "排名", range(1, len(res) + 1))
    return res, live_hist


# ----------------------------------------------------------------------------
def backtest(provider: BaseProvider, cfg: dict, universe: str | None = None, days: int = 250):
    """日线回测：以当日收盘价近似 14:30 买入价，每天取得分前 N，统计次日表现。

    返回 (汇总 dict, 每笔交易 DataFrame, 每日收益 DataFrame[strategy, benchmark])。
    局限：收盘价≠14:30 价格；使用当前指数成分股（幸存者偏差）。
    """
    p = params(cfg)
    universe = universe or p["universe"]
    print("  获取全市场实时行情（约 10~60 秒）…", file=sys.stderr, flush=True)
    try:
        spot = provider.spot()
    except Exception:  # noqa: BLE001
        spot = None
    codes = resolve_universe(provider, cfg, universe, spot)
    print(f"  回测股票池 {universe}: {len(codes)} 只，最近 {days} 个交易日", file=sys.stderr)
    print("  下载日线（首次较慢，之后读缓存）…", file=sys.stderr, flush=True)
    hist = provider.daily_batch(codes, max_workers=int(cfg["data"]["max_workers"]),
                                progress=_progress)
    frames = [stock_features(df, code, with_forward=True) for code, df in hist.items()
              if len(df) >= 80]
    if not frames:
        return {}, pd.DataFrame(), pd.DataFrame()
    allf = pd.concat(frames)
    allf.index.name = "date"
    allf = allf.reset_index()
    all_dates = sorted(allf["date"].unique())[-days - 1:]
    allf = allf[allf["date"].isin(all_dates)].dropna(subset=["ret_close"])
    scored = score_cross_section(allf, p)
    picks = (scored.sort_values(["date", "score"], ascending=[True, False])
             .groupby("date").head(int(p["top_n"])))
    pool = allf[~allf["limit"]]
    daily = picks.groupby("date")["ret_close"].mean()
    bench = pool.groupby("date")["ret_close"].mean().reindex(daily.index)

    def pct(v):
        return round(float(v) * 100, 2)

    # 分三段看稳定性
    segs = np.array_split(np.array(sorted(daily.index)), 3)
    seg_txt = []
    for i, sd in enumerate(segs, 1):
        s, b = daily.loc[sd], bench.loc[sd]
        seg_txt.append(f"{pct(s.mean()):+.2f}% vs 池{pct(b.mean()):+.2f}%")

    summary = {
        "回测交易日": len(daily),
        "每日选股数": int(p["top_n"]),
        "次日开盘平均收益%": pct(picks["ret_open"].mean()),
        "次日最高平均涨幅%": pct(picks["ret_high"].mean()),
        "次日收盘平均收益%": pct(picks["ret_close"].mean()),
        "次日收盘胜率%": pct((picks["ret_close"] > 0).mean()),
        "持有2日平均收益%": pct(picks["ret_2d"].mean()),
        "同期股票池次日平均%": pct(pool["ret_close"].mean()),
        "同期股票池次日胜率%": pct((pool["ret_close"] > 0).mean()),
        "分段次日均值(前/中/后)": " | ".join(seg_txt),
        "每日换仓累计收益%(不计成本)": pct((1 + daily).prod() - 1),
        "每日换仓累计收益%(扣成本)": pct((1 + daily - p["cost"]).prod() - 1),
        "股票池等权累计%": pct((1 + bench).prod() - 1),
    }
    trades = picks[["date", "code", "score", "r1", "r20", "ret_open", "ret_high", "ret_close",
                    "ret_2d"]].copy()
    return summary, trades, pd.DataFrame({"strategy": daily - p["cost"], "benchmark": bench})


# ----------------------------------------------------------------------------
def save_picks(res: pd.DataFrame, out_dir: str | Path) -> Path | None:
    if res is None or res.empty:
        return None
    d = Path(out_dir) / "tail_picks"
    d.mkdir(parents=True, exist_ok=True)
    path = d / f"picks_{now_cn():%Y%m%d}.csv"
    res.to_csv(path, index=False, encoding="utf-8-sig")
    return path


def review(provider: BaseProvider, cfg: dict, spot: pd.DataFrame | None = None,
           max_files: int = 30) -> tuple[pd.DataFrame, pd.DataFrame]:
    """复盘历史选股：每期选股在“下一个交易日”的开盘/最高/收盘表现（相对选股价）。"""
    d = Path(cfg["output_dir"]) / "tail_picks"
    files = sorted(d.glob("picks_*.csv"))[-max_files:]
    today = pd.Timestamp(now_cn().date())
    files = [f for f in files if pd.Timestamp(datetime.strptime(f.stem[6:], "%Y%m%d")) < today]
    if not files:
        return pd.DataFrame(), pd.DataFrame()
    picks = []
    for f in files:
        df = pd.read_csv(f, dtype={"代码": str})
        df["选股日"] = pd.Timestamp(datetime.strptime(f.stem[6:], "%Y%m%d"))
        picks.append(df)
    picks = pd.concat(picks, ignore_index=True)
    hist = provider.daily_batch(picks["代码"].unique(),
                                max_workers=int(cfg["data"]["max_workers"]))
    sidx = spot.set_index("code") if spot is not None else None
    rows = []
    for _, r in picks.iterrows():
        code, day = r["代码"], r["选股日"]
        df = hist.get(code)
        if df is None:
            continue
        if sidx is not None and code in sidx.index:
            df = merge_live_bar(df, sidx.loc[code], today)
        after = df[df.index > day]
        if after.empty:
            continue
        nb = after.iloc[0]
        base = float(r["现价"])
        intraday = after.index[0] == today and is_trading_time()
        rows.append({"选股日": day.strftime("%Y-%m-%d"), "代码": code, "名称": r.get("名称", ""),
                     "选股价": base, "得分": r.get("得分"),
                     "次日开盘%": round((nb["open"] / base - 1) * 100, 2),
                     "次日最高%": round((nb["high"] / base - 1) * 100, 2),
                     "次日收盘%": round((nb["close"] / base - 1) * 100, 2),
                     "状态": "盘中" if intraday else "已收盘"})
    detail = pd.DataFrame(rows)
    if detail.empty:
        return pd.DataFrame(), detail
    g = detail.groupby("选股日")
    summary = pd.DataFrame({
        "只数": g.size(),
        "次日开盘均%": g["次日开盘%"].mean().round(2),
        "次日最高均%": g["次日最高%"].mean().round(2),
        "次日收盘均%": g["次日收盘%"].mean().round(2),
        "收盘上涨占比%": (g["次日收盘%"].apply(lambda s: (s > 0).mean()) * 100).round(0),
        "状态": g["状态"].first(),
    }).reset_index()
    return summary, detail
