# A股量化工具

用 AKShare 免费行情数据做两件事：**选股筛选** 和 **盘中实时信号提醒**。命令行运行，结果输出为终端表格、CSV 和带K线图的 HTML 报告。

> ⚠ 仅供学习研究，不构成投资建议。

## 安装

需要 Python 3.9 及以上（macOS 自带的 python3 即可）。

```bash
cd ~/claude-workspace/stock
python3 -m venv .venv && source .venv/bin/activate
pip3 install -r requirements.txt
```

先用离线模拟数据试一遍（不需要联网）：

```bash
python3 main.py --demo screen -s all --report
python3 main.py --demo monitor --once
```

## 常用命令

| 目的 | 命令 |
|---|---|
| 查看内置策略及参数 | `python3 main.py strategies` |
| 沪深300 今日 MACD 金叉 | `python3 main.py screen -s macd -u hs300` |
| 全市场活跃股近 3 日的均线/MACD 买点，并生成报告 | `python3 main.py screen -s ma_cross,macd -u all -l 3 --report` |
| 三个技术策略同时扫描（看共振数） | `python3 main.py screen -s all -u zz500 -l 2 --report` |
| 卖出信号扫描自选股 | `python3 main.py screen -s all -u watchlist -d sell` |
| 多因子打分 Top 30 | `python3 main.py screen -s multi_factor --top 30 --report` |
| 盘中监控自选股 | `python3 main.py monitor` |
| 临时监控几只股票，30 秒刷新 | `python3 main.py monitor --codes 600519,300750 -i 30` |
| 个股K线 + 指标图 | `python3 main.py chart 600519 000858` |
| 预下载日线缓存 | `python3 main.py update -u hs300` |

**股票池 `-u`**：`hs300`、`zz500`、`zz1000`、`sz50`、`kc50`、`cyb`、`all`（过滤后按成交额取前 N，默认 300）、`watchlist`（自选股）、`index:000905`（任意中证指数代码），或者直接写 `600519,000858`。

结果保存在 `output/` 目录：`screen_*.csv`（Excel 可以直接打开）、`report_*.html`（报告会自动在浏览器打开，加 `--no-open` 可以关掉）、`alerts.log`（提醒记录）。

## 内置策略

| 名称 | 逻辑 | 主要参数 |
|---|---|---|
| `ma_cross` 双均线 | MA5 上穿 MA20 买入（可要求放量），下穿卖出 | fast / slow / volume_confirm |
| `macd` MACD | DIF 上穿 DEA 为金叉、下穿为死叉；可以只认零轴上方的金叉 | fast / slow / signal / above_zero |
| `mean_reversion` 布林带+RSI | 跌破下轨且 RSI<30 之后重新站回下轨时买入；突破上轨且 RSI>70 之后跌回上轨时卖出 | boll_period / boll_std / rsi_low / rsi_high |
| `multi_factor` 多因子 | 全市场快照中取 60 日动量、年初至今涨幅、PE、PB、换手率、市值，先 MAD 去极值、再 z-score 标准化，按权重加总后排名 | factors 的权重与方向、max_pe |

所有参数都在 `config.yaml` 里改。

## 尾盘选股（每天 14:30）

在 14:30 按一套尾盘经验规则打分，挑出次日上涨概率相对较高的候选股：

- **硬条件**：当日涨幅 2%–6% 且未涨停、量比 ≥ 1.2、换手率 3%–15%、流通市值 30–300 亿、价格在分时均价线上方、站上 20 日线、上影线 ≤ 2%、60 日涨幅不超过 60%
- **打分（满分 100）**：量比 25 + 均线多头 20 + 接近 20 日新高 20 + 强于均价线 15 + 收在高位 10 + MACD 多头 10

```bash
python3 main.py tail                       # 立即运行一次（复盘之前的选股 + 今日选股 + 通知 + 报告）
python3 main.py tail --backtest -u zz500   # 用最近 250 个交易日回测这套规则
python3 main.py tail --review              # 只看历史选股的复盘
```

每次运行都会把当天的选股存到 `output/tail_picks/`，下一次运行时自动算出这些股票次日的开盘、最高、收盘涨幅，逐渐积累真实胜率。

**请先跑 `--backtest`**：看次日胜率和平均收益是否明显好于“同期全池”，不好就调整 `config.yaml` 的 `tail` 参数。回测有几处近似：用收盘价代替 14:30 的价格；历史流通市值拿不到，所以没有过滤；指数成分股存在幸存者偏差。

建议每个交易日 14:30–14:50 之间手动运行一次 `python3 main.py tail`。（如果以后想自动运行，可以用 `bash scripts/install_schedule.sh` 安装定时任务。）

## 实时监控

`monitor` 在交易时段（9:30–11:30、13:00–15:00）按设定间隔刷新自选股：

1. **价格提醒**：在 `watchlist` 里给股票加 `above` / `below` / `pct_up` / `pct_down`
2. **策略信号**：把最新价拼成当天的K线，再跑一遍策略，出现金叉/死叉等信号时提醒

提醒会发到终端（买入红色、卖出绿色）和 macOS 系统通知，也可以推送到手机：在 `config.yaml` 的 `monitor.notify.webhook` 中填好 `type`（`wecom` / `dingtalk` / `feishu` / `serverchan`）和 `url`。如果用钉钉机器人，安全设置里的关键词请设成“信号”或“提醒”。

同一只股票、同一个信号，一天内只提醒一次（重启后也不会重复）。盘中信号基于还没收盘的K线，收盘前可能消失。

## 目录结构

```
main.py              命令行入口
config.yaml          全部配置（股票池过滤、策略参数、自选股、通知）
quant/
  data.py            AKShare 数据获取 + 本地缓存；MockProvider 离线模拟数据
  indicators.py      MA / EMA / MACD / RSI / 布林带 / ATR
  strategies/        策略（technical.py 技术面，multi_factor.py 多因子）
  screener.py        选股扫描
  monitor.py         实时监控
  notifier.py        通知通道
  report.py          HTML 图表报告（Plotly，红涨绿跌）
  tail.py            尾盘选股：打分、回测、复盘
scripts/
  install_schedule.sh  macOS 定时任务安装（launchd）
tests/               单元测试：python -m pytest -q
```

## 自己写策略

在 `quant/strategies/technical.py` 中继承 `Strategy`，实现 `compute(df)`，输出 `signal` 列（1 买 / -1 卖 / 0）和 `reason` 列，然后在 `strategies/__init__.py` 的 `TECHNICAL` 里注册。`screen`、`monitor`、`chart` 都能直接用上。

```python
class MyStrategy(Strategy):
    name, label = "my", "放量突破20日新高"
    def compute(self, df):
        hh = df["high"].rolling(20).max().shift()
        up = (df["close"] > hh) & (df["volume"] > 2 * df["volume"].rolling(20).mean())
        df["signal"] = up.astype(int)
        df["reason"] = up.map({True: "放量创20日新高", False: ""})
        return df
```

## 常见问题

- **下载慢或报错**：东方财富接口有频率限制，可以把 `data.max_workers` 调到 2。日线收盘后只下载一次，之后读 `data/cache`。
- **`universe=all` 扫描慢**：第一次需要下载约 300 只股票的日线，之后走缓存。
- **AKShare 接口变了**：`pip install -U akshare` 升级。
