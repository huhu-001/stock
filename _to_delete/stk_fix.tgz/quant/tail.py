"""尾盘选股（14:30）：挑选“次日有较大概率延续上涨”的候选股，并用历史数据检验、每日复盘。

思路（A股常见的尾盘选股经验规则，量化成打分）：
  硬条件  当日涨幅 2%~6%、未涨停、量比放大、换手适中、价格在分时均价线上方、
          站上 20 日线、上影线短、近 60 日未过度炒作
  打分    量比(25) + 均线多头(20) + 接近 20 日新高(20) + 强于均价线(15)
          + 收在高位(10) + MACD 多头(10) = 100

重要：这是概率筛选，不是预测。请先用 --backtest 看历史胜率，再结合每日复盘判断是否可用。
"""
from __future__ import annotations

import logging
import sys
from datetime import datetime
from pathlib import Path

import numpy as np
import pandas as pd

from . import indicators as ind
from .data import BaseProvider
from .monitor import merge_live_bar
from .screener import _progress, apply_universe_filters, resolve_universe
from .timeutil import SESSIONS, is_trading_time, now_cn

log = logging.getLogger(__name__)

DEFAULTS = {
    "top_n": 10, "max_candidates": 200, "min_score": 50,
    "pct_min": 2.0, "pct_max": 6.0, "turnover_min": 3.0, "turnover_max": 15.0,
    "volume_ratio_min": 1.2, "float_mv_min": 3e9, "float_mv_max": 3e10,
    "max_upper_shadow": 0.02, "near_high": 0.05, "max_chg_60d": 60.0,
    "cost": 0.0015,   # 回测单次买卖往返成本（佣金+印花税+滑点）
}


def params(cfg: dict) -> dict:
    return {**DEFAULTS, **(cfg.get("tail") or {})}


def limit_pct(code: str) -> float:
    return 20.0 if code.startswith(("300", "301", "688")) else 10.0


def elapsed_fraction(dt: datetime | None = None) -> float:
    """当日已交易时间占全天 240 分钟的比例，用于把盘中成交量折算成全天。"""
    dt = dt or now_cn()
    if not is_trading_time(dt):
        return 1.0
    mins = 0.0
    t = dt.hour * 60 + dt.minute
    for s, e in SESSIONS:
        a, b = s.hour * 60 + s.minute, e.hour * 60 + e.minute
        mins += max(0, min(t, b) - a)
    return max(mins / 240, 0.05)


def tail_features(df: pd.DataFrame, code: str, p: dict, elapsed: float = 1.0) -> pd.DataFrame:
    """对日线逐行计算尾盘选股特征、硬条件与得分（最后一行可以是盘中实时K线）。"""
    c, o, h, v = df["close"], df["open"], df["high"], df["volume"]
    f = pd.DataFrame(index=df.index)
    f["close"] = c
    f["pct"] = (c / c.shift() - 1) * 100
    vwap = df["amount"] / (v * 100)                     # 成交额/成交股数 = 当日均价
    vwap = vwap.where((vwap > df["low"] * 0.95) & (vwap < h * 1.05))
    f["vwap_gap"] = (c / vwap - 1).fillna(0)
    avg5 = v.shift().rolling(5).mean()
    f["vr"] = v / elapsed / avg5
    # 盘中最后一根：成交量按已交易时长折算，其余行 elapsed=1
    if elapsed < 1:
        f.loc[f.index[:-1], "vr"] = (v / avg5).iloc[:-1]
    ma5, ma10, ma20 = ind.sma(c, 5), ind.sma(c, 10), ind.sma(c, 20)
    hh20 = h.shift().rolling(20).max()
    f["dist_high"] = (hh20 - c) / hh20                  # 距前 20 日最高价的距离
    f["upper"] = (h - c) / c                            # 上影线比例
    dif, dea, _ = ind.macd(c)
    f["chg60"] = (c / c.shift(60) - 1) * 100
    f["turnover"] = df["turnover"] if "turnover" in df else np.nan
    lim = limit_pct(code)

    hard = (f["pct"].between(p["pct_min"], p["pct_max"]) & (f["pct"] < lim - 0.3)
            & (f["vr"] >= p["volume_ratio_min"]) & (f["vwap_gap"] >= -0.002)
            & (c > ma20) & (f["upper"] <= p["max_upper_shadow"])
            & (f["chg60"].fillna(0) < p["max_chg_60d"]))
    if f["turnover"].notna().any():
        hard &= f["turnover"].between(p["turnover_min"], p["turnover_max"])

    trend = ((ma5 > ma10).astype(int) + (ma10 > ma20).astype(int) + (c > ma5).astype(int)) / 3
    s_vr = ((f["vr"] - 1) / 2).clip(0, 1) * 25
    s_trend = trend * 20
    s_high = (1 - f["dist_high"] / p["near_high"]).clip(0, 1) * 20
    s_vwap = (f["vwap_gap"] / 0.02).clip(0, 1) * 15
    s_close = (1 - f["upper"] / p["max_upper_shadow"]).clip(0, 1) * 10
    s_macd = (dif > dea).astype(int) * 10
    f["score"] = (s_vr + s_trend + s_high + s_vwap + s_close + s_macd).round(1)
    f["pass"] = hard.fillna(False) & (f["score"] >= p["min_score"])

    tags = []
    for i in range(len(f)):
        t = []
        if f["vr"].iat[i] >= 2: t.append("明显放量")
        elif f["vr"].iat[i] >= 1.5: t.append("温和放量")
        if trend.iat[i] == 1: t.append("均线多头")
        if f["dist_high"].iat[i] <= 0: t.append("创20日新高")
        elif f["dist_high"].iat[i] <= 0.02: t.append("逼近前高")
        if f["vwap_gap"].iat[i] >= 0.01: t.append("强于均价线")
        if dif.iat[i] > dea.iat[i]: t.append("MACD多头")
        tags.append("、".join(t))
    f["tags"] = tags
    return f


# ----------------------------------------------------------------------------
def pick_live(provider: BaseProvider, cfg: dict, spot: pd.DataFrame | None = None):
    """实时尾盘选股。返回 (结果表, {code: 含实时K线的日线})。"""
    p = params(cfg)
    spot = spot if spot is not None else provider.spot()
    pool = apply_universe_filters(spot, cfg["universe"])
    pool = pool[pool["pct_chg"].between(p["pct_min"], p["pct_max"])]
    if "turnover" in pool:
        pool = pool[pool["turnover"].between(p["turnover_min"], p["turnover_max"])]
    if "float_mv" in pool:
        pool = pool[pool["float_mv"].between(p["float_mv_min"], p["float_mv_max"])]
    if "volume_ratio" in pool:
        pool = pool[pool["volume_ratio"].fillna(99) >= p["volume_ratio_min"]]
    pool = pool.sort_values("amount", ascending=False).head(int(p["max_candidates"]))
    print(f"  初筛候选 {len(pool)} 只，下载日线计算特征…", file=sys.stderr)
    if pool.empty:
        return pd.DataFrame(), {}
    hist = provider.daily_batch(pool["code"], max_workers=int(cfg["data"]["max_workers"]),
                                progress=_progress)
    today = pd.Timestamp(now_cn().date())
    el = elapsed_fraction()
    sidx = pool.set_index("code")
    rows, live_hist = [], {}
    for code, df in hist.items():
        if len(df) < 70:
            continue
        q = sidx.loc[code]
        live = merge_live_bar(df, q, today)
        live_hist[code] = live
        f = tail_features(live, code, p, elapsed=el).iloc[-1]
        if not f["pass"]:
            continue
        rows.append({"代码": code, "名称": q.get("name", ""), "现价": round(float(q["price"]), 2),
                     "涨幅%": round(float(q["pct_chg"]), 2), "得分": f["score"],
                     "量比": round(float(q.get("volume_ratio", f["vr"])), 2),
                     "换手%": round(float(q.get("turnover", np.nan)), 2),
                     "流通市值(亿)": round(float(q.get("float_mv", np.nan)) / 1e8, 1),
                     "距20日高%": round(float(f["dist_high"]) * 100, 1),
                     "亮点": f["tags"]})
    res = pd.DataFrame(rows)
    if not res.empty:
        res = res.sort_values("得分", ascending=False).head(int(p["top_n"])).reset_index(drop=True)
        res.insert(0, "排名", range(1, len(res) + 1))
    return res, live_hist


# ----------------------------------------------------------------------------
def backtest(provider: BaseProvider, cfg: dict, universe: str = "hs300", days: int = 250):
    """用日线近似回测：以当日收盘价近似 14:30 买入价，统计次日表现。

    返回 (汇总 dict, 每笔交易 DataFrame, 每日组合收益 Series)。
    局限：收盘价≠14:30 价格；历史流通市值不可得（未过滤）；指数成分股存在幸存者偏差。
    """
    p = params(cfg)
    try:
        spot = provider.spot()
    except Exception:  # noqa: BLE001
        spot = None
    codes = resolve_universe(provider, cfg, universe, spot)
    print(f"  回测股票池 {universe}: {len(codes)} 只，最近 {days} 个交易日", file=sys.stderr)
    hist = provider.daily_batch(codes, days=int(days * 1.6) + 120,
                                max_workers=int(cfg["data"]["max_workers"]), progress=_progress)
    frames = []
    for code, df in hist.items():
        if len(df) < 80:
            continue
        f = tail_features(df, code, p)
        f["code"] = code
        f["ret_open"] = df["open"].shift(-1) / df["close"] - 1
        f["ret_high"] = df["high"].shift(-1) / df["close"] - 1
        f["ret_close"] = df["close"].shift(-1) / df["close"] - 1
        f["ret_2d"] = df["close"].shift(-2) / df["close"] - 1
        frames.append(f.iloc[-days - 1:])
    if not frames:
        return {}, pd.DataFrame(), pd.Series(dtype=float)
    allf = pd.concat(frames).dropna(subset=["ret_close"])
    allf.index.name = "date"
    allf = allf.reset_index()
    picks = (allf[allf["pass"]].sort_values(["date", "score"], ascending=[True, False])
             .groupby("date").head(int(p["top_n"])))
    daily = picks.groupby("date")["ret_close"].mean() - p["cost"]
    all_dates = pd.Index(sorted(allf["date"].unique()))
    daily = daily.reindex(all_dates).fillna(0.0)   # 没有选出股票的日子空仓
    bench = allf.groupby("date")["ret_close"].mean()

    def pct(x):
        return round(float(x) * 100, 2)

    n = len(picks)
    summary = {
        "回测交易日": len(all_dates),
        "有选股的天数": int(picks["date"].nunique()),
        "选股总次数": n,
        "次日开盘平均收益%": pct(picks["ret_open"].mean()) if n else None,
        "次日最高平均涨幅%": pct(picks["ret_high"].mean()) if n else None,
        "次日收盘平均收益%": pct(picks["ret_close"].mean()) if n else None,
        "次日收盘胜率%": pct((picks["ret_close"] > 0).mean()) if n else None,
        "次日冲高≥2%概率%": pct((picks["ret_high"] >= 0.02).mean()) if n else None,
        "持有2日平均收益%": pct(picks["ret_2d"].mean()) if n else None,
        "同期全池次日平均%": pct(allf["ret_close"].mean()),
        "同期全池次日胜率%": pct((allf["ret_close"] > 0).mean()),
        "策略累计收益%(扣成本)": pct((1 + daily).prod() - 1),
        "全池等权累计%": pct((1 + bench).prod() - 1),
        "最大回撤%": pct(((1 + daily).cumprod() / (1 + daily).cumprod().cummax() - 1).min()),
    }
    trades = picks[["date", "code", "score", "pct", "vr", "ret_open", "ret_high", "ret_close",
                    "ret_2d", "tags"]].copy()
    return summary, trades, pd.DataFrame({"strategy": daily, "benchmark": bench})


# ----------------------------------------------------------------------------
def save_picks(res: pd.DataFrame, out_dir: str | Path) -> Path | None:
    if res is None or res.empty:
        return None
    d = Path(out_dir) / "tail_picks"
    d.mkdir(parents=True, exist_ok=True)
    path = d / f"picks_{now_cn():%Y%m%d}.csv"
    res.to_csv(path, index=False, encoding="utf-8-sig")
    return path


def review(provider: BaseProvider, cfg: dict, spot: pd.DataFrame | None = None,
           max_files: int = 30) -> tuple[pd.DataFrame, pd.DataFrame]:
    """复盘历史选股：每期选股在“下一个交易日”的开盘/最高/收盘表现。

    返回 (每期汇总, 明细)。下一个交易日如果是今天且在盘中，用实时价格（标注“盘中”）。
    """
    d = Path(cfg["output_dir"]) / "tail_picks"
    files = sorted(d.glob("picks_*.csv"))[-max_files:]
    today = pd.Timestamp(now_cn().date())
    files = [f for f in files if pd.Timestamp(datetime.strptime(f.stem[6:], "%Y%m%d")) < today]
    if not files:
        return pd.DataFrame(), pd.DataFrame()
    picks = []
    for f in files:
        df = pd.read_csv(f, dtype={"代码": str})
        df["选股日"] = pd.Timestamp(datetime.strptime(f.stem[6:], "%Y%m%d"))
        picks.append(df)
    picks = pd.concat(picks, ignore_index=True)
    hist = provider.daily_batch(picks["代码"].unique(),
                                max_workers=int(cfg["data"]["max_workers"]))
    sidx = spot.set_index("code") if spot is not None else None
    rows = []
    for r in picks.itertuples(index=False):
        code, day = r.代码, r.选股日
        df = hist.get(code)
        if df is None:
            continue
        if sidx is not None and code in sidx.index:
            df = merge_live_bar(df, sidx.loc[code], today)
        after = df[df.index > day]
        if after.empty:
            continue
        nb = after.iloc[0]
        base = float(r.现价)
        intraday = after.index[0] == today and is_trading_time()
        rows.append({"选股日": day.strftime("%Y-%m-%d"), "代码": code, "名称": r.名称,
                     "选股价": base, "得分": r.得分,
                     "次日开盘%": round((nb["open"] / base - 1) * 100, 2),
                     "次日最高%": round((nb["high"] / base - 1) * 100, 2),
                     "次日收盘%": round((nb["close"] / base - 1) * 100, 2),
                     "状态": "盘中" if intraday else "已收盘"})
    detail = pd.DataFrame(rows)
    if detail.empty:
        return pd.DataFrame(), detail
    g = detail.groupby("选股日")
    summary = pd.DataFrame({
        "只数": g.size(),
        "次日开盘均%": g["次日开盘%"].mean().round(2),
        "次日最高均%": g["次日最高%"].mean().round(2),
        "次日收盘均%": g["次日收盘%"].mean().round(2),
        "收盘上涨占比%": (g["次日收盘%"].apply(lambda s: (s > 0).mean()) * 100).round(0),
        "状态": g["状态"].first(),
    }).reset_index()
    return summary, detail
