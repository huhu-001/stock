from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from quant import indicators as ind  # noqa: E402
from quant import strategies as S  # noqa: E402
from quant.config import load_config  # noqa: E402
from quant.data import MockProvider, norm_code  # noqa: E402
from quant.monitor import Monitor, merge_live_bar  # noqa: E402
from quant.notifier import Notifier  # noqa: E402
from quant.report import build_report  # noqa: E402
from quant.screener import apply_universe_filters, screen_multi_factor, screen_technical  # noqa: E402


def make_df(close):
    close = np.asarray(close, dtype=float)
    idx = pd.bdate_range("2025-01-01", periods=len(close))
    df = pd.DataFrame({"open": close, "high": close * 1.01, "low": close * 0.99, "close": close,
                       "volume": 1e5, "amount": close * 1e7}, index=idx)
    df.index.name = "date"
    return df


@pytest.fixture
def cfg(tmp_path):
    c = load_config()
    c["output_dir"] = str(tmp_path)
    return c


# ---------------- indicators ----------------
def test_norm_code():
    assert norm_code("sh600519") == "600519"
    assert norm_code(1) == "000001"
    assert norm_code("000001.SZ") == "000001"


def test_sma_ema_macd():
    s = pd.Series(np.arange(1, 51, dtype=float))
    assert ind.sma(s, 5).iloc[-1] == pytest.approx(48.0)
    assert ind.sma(s, 5).isna().sum() == 4
    dif, dea, hist = ind.macd(s)
    assert (hist == 2 * (dif - dea)).all()
    assert dif.iloc[-1] > 0  # 单边上涨 DIF 为正


def test_rsi_bounds():
    rng = np.random.default_rng(0)
    s = pd.Series(100 + rng.normal(0, 1, 300).cumsum())
    r = ind.rsi(s).dropna()
    assert r.between(0, 100).all()
    assert ind.rsi(pd.Series(np.arange(1, 40, dtype=float))).iloc[-1] == 100


def test_bollinger_order():
    rng = np.random.default_rng(1)
    s = pd.Series(50 + rng.normal(0, 1, 100).cumsum())
    mid, up, low = ind.bollinger(s)
    ok = mid.notna()
    assert (up[ok] >= mid[ok]).all() and (mid[ok] >= low[ok]).all()


def test_cross():
    a = pd.Series([1, 2, 3, 2, 1.0])
    b = pd.Series([2, 2, 2, 2, 2.0])
    assert ind.cross_up(a, b).tolist() == [False, False, True, False, False]
    assert ind.cross_down(a, b).tolist() == [False, False, False, False, True]


# ---------------- strategies ----------------
def test_ma_cross_signal():
    close = [10] * 30 + list(np.linspace(10, 8, 15)) + list(np.linspace(8, 12, 15))
    st = S.MACrossStrategy(fast=5, slow=20, volume_confirm=False)
    res = st.run(make_df(close))
    assert (res["signal"] == 1).sum() >= 1
    assert (res["signal"] == -1).sum() >= 1
    assert st.state(res.iloc[-1]) == "均线多头"


def test_macd_signal():
    close = list(np.linspace(20, 10, 60)) + list(np.linspace(10, 16, 30))
    res = S.MACDStrategy().run(make_df(close))
    buys = res[res["signal"] == 1]
    assert len(buys) >= 1 and "金叉" in buys["reason"].iloc[0]


def test_mean_reversion_signal():
    close = [20.0] * 40 + [19.5, 19, 18, 17, 16, 15.5, 15.3] + [17.5, 18, 18.5]
    rng = np.random.default_rng(2)
    close = np.array(close) + np.r_[rng.normal(0, 0.05, 40), np.zeros(10)]
    res = S.MeanReversionStrategy().run(make_df(close))
    assert (res["signal"] == 1).any()


def test_short_history_returns_empty():
    assert S.MACDStrategy().run(make_df([10] * 10)).empty


def test_multi_factor_ranking():
    spot = MockProvider().spot()
    scored = S.MultiFactorStrategy().score(spot)
    assert (scored["pe"] > 0).all()
    assert scored["score"].is_monotonic_decreasing
    assert scored["rank"].iloc[0] == 1


# ---------------- screener / monitor / report ----------------
def test_universe_filters(cfg):
    spot = MockProvider().spot()
    out = apply_universe_filters(spot, cfg["universe"])
    assert not out["name"].str.contains("ST").any()
    assert (out["amount"] >= cfg["universe"]["min_amount"]).all()


def test_screen_technical(cfg):
    res, hist = screen_technical(MockProvider(), cfg, ["ma_cross", "macd"], "hs300", lookback=10)
    assert len(hist) > 0
    if not res.empty:
        assert set(res["信号"]) == {"买入"}
        assert {"代码", "策略", "共振数"} <= set(res.columns)


def test_screen_multi_factor(cfg):
    res = screen_multi_factor(MockProvider(), cfg, top=10)
    assert len(res) == 10 and "综合得分" in res.columns


def test_merge_live_bar():
    df = make_df([10, 11, 12])
    today = df.index[-1] + pd.offsets.BDay(1)
    q = pd.Series({"price": 13.0, "open": 12.1, "high": 13.2, "low": 12.0, "volume": 5e4})
    out = merge_live_bar(df, q, today)
    assert len(out) == 4 and out["close"].iloc[-1] == 13.0
    out2 = merge_live_bar(out, pd.Series({**q, "price": 13.5}), today)
    assert len(out2) == 4 and out2["close"].iloc[-1] == 13.5


def test_monitor_tick_and_dedupe(cfg):
    cfg["watchlist"] = [{"code": "600519", "pct_up": -100}]   # 必然触发的价格提醒
    n = Notifier({"console": False, "macos": False}, Path(cfg["output_dir"]) / "alerts.log")
    m = Monitor(MockProvider(), cfg, n)
    m.prepare()
    board = m.tick()
    assert len(board) == 1
    lines = (Path(cfg["output_dir"]) / "alerts.log").read_text(encoding="utf-8").splitlines()
    m.tick()  # 同一天不重复提醒
    lines2 = (Path(cfg["output_dir"]) / "alerts.log").read_text(encoding="utf-8").splitlines()
    assert len(lines) >= 1 and len(lines) == len(lines2)


def test_report(cfg, tmp_path):
    res, hist = screen_technical(MockProvider(), cfg, ["macd"], "watchlist", lookback=200,
                                 direction="both")
    p = build_report("测试", res, hist, ["macd", "mean_reversion"], tmp_path / "r.html", cfg=cfg)
    text = p.read_text(encoding="utf-8")
    assert "plotly.min.js" in text and (tmp_path / "plotly.min.js").exists()


def test_akshare_provider_mapping(tmp_path, monkeypatch):
    """用伪造的 akshare 返回值验证列名映射与缓存（不联网）。"""
    import types
    fake = types.SimpleNamespace()
    dates = pd.bdate_range(end=pd.Timestamp.today().normalize(), periods=300)
    fake.stock_zh_a_hist = lambda **kw: pd.DataFrame({
        "日期": dates.strftime("%Y-%m-%d"), "股票代码": kw["symbol"], "开盘": 10.0, "收盘": 10.5,
        "最高": 11.0, "最低": 9.5, "成交量": 1000, "成交额": 1e6, "振幅": 1.0, "涨跌幅": 0.5,
        "涨跌额": 0.05, "换手率": 1.2})
    fake.stock_zh_a_spot_em = lambda: pd.DataFrame({
        "序号": [1], "代码": ["600519"], "名称": ["贵州茅台"], "最新价": ["1500.1"], "涨跌幅": [1.2],
        "今开": [1490], "最高": [1510], "最低": [1480], "昨收": [1482], "成交量": [1e4],
        "成交额": [1.5e9], "换手率": [0.3], "市盈率-动态": [25.1], "市净率": [8.2],
        "总市值": [1.9e12], "流通市值": [1.9e12], "60日涨跌幅": [3.3], "年初至今涨跌幅": [5.5]})
    monkeypatch.setitem(sys.modules, "akshare", fake)
    from quant.data import AKShareProvider
    p = AKShareProvider(cache_dir=str(tmp_path), history_days=400)
    d = p.daily("600519")
    assert list(d.columns) == ["open", "close", "high", "low", "volume", "amount", "pct_chg",
                               "turnover"]
    assert (tmp_path / "daily" / "600519_qfq.csv").exists()
    fake.stock_zh_a_hist = lambda **kw: (_ for _ in ()).throw(RuntimeError("should use cache"))
    assert len(p.daily("600519")) == 300
    s = p.spot()
    assert s.loc[0, "price"] == pytest.approx(1500.1) and s.loc[0, "pe"] == 25.1


# ---------------- 尾盘选股 ----------------
from quant import tail  # noqa: E402


def test_tail_features_strong_stock():
    # 稳步上涨后放量涨 4%、收在最高价附近
    close = list(np.linspace(10, 12, 80)) + [12.5]
    df = make_df(close)
    df["high"] = df["close"] * 1.003
    df["low"] = df["close"] * 0.97
    df["volume"] = 1e5
    df.iloc[-1, df.columns.get_loc("volume")] = 3e5
    df["amount"] = df["volume"] * 100 * df["close"] * 0.99   # 均价略低于收盘价
    df["turnover"] = 5.0
    f = tail.tail_features(df, "600000", tail.params({}))
    last = f.iloc[-1]
    assert last["pass"] and last["score"] >= 70
    assert "放量" in last["tags"]


def test_tail_rejects_limit_up_and_weak():
    close = list(np.linspace(10, 12, 80)) + [13.2]  # +10% 涨停
    df = make_df(close)
    df["turnover"] = 5.0
    f = tail.tail_features(df, "600000", tail.params({}))
    assert not f.iloc[-1]["pass"]


def test_elapsed_fraction():
    from quant.timeutil import CN_TZ
    from datetime import datetime
    assert tail.elapsed_fraction(datetime(2026, 9, 24, 14, 30, tzinfo=CN_TZ)) == pytest.approx(210 / 240)
    assert tail.elapsed_fraction(datetime(2026, 9, 24, 10, 30, tzinfo=CN_TZ)) == pytest.approx(60 / 240)
    assert tail.elapsed_fraction(datetime(2026, 9, 26, 14, 30, tzinfo=CN_TZ)) == 1.0  # 周六


def test_tail_backtest(cfg):
    summary, trades, curve = tail.backtest(MockProvider(), cfg, "hs300", days=120)
    assert summary["回测交易日"] > 100
    assert {"strategy", "benchmark"} <= set(curve.columns)
    if len(trades):
        assert trades.groupby("date").size().max() <= tail.params(cfg)["top_n"]


def test_tail_pick_save_review(cfg):
    cfg["tail"] = {"pct_min": -20, "pct_max": 20, "turnover_min": 0, "turnover_max": 100,
                   "volume_ratio_min": 0, "float_mv_min": 0, "float_mv_max": 1e15,
                   "max_upper_shadow": 1, "min_score": 0, "max_chg_60d": 1e9}
    cfg["universe"]["min_amount"] = 0
    res, hist = tail.pick_live(MockProvider(), cfg)
    assert not res.empty and res["得分"].is_monotonic_decreasing
    # 伪造一份“前天”的选股记录用于复盘
    d = Path(cfg["output_dir"]) / "tail_picks"
    d.mkdir(parents=True)
    old = res.copy()
    day = (pd.Timestamp.today() - pd.offsets.BDay(2)).strftime("%Y%m%d")
    old.to_csv(d / f"picks_{day}.csv", index=False, encoding="utf-8-sig")
    summary, detail = tail.review(MockProvider(), cfg)
    assert len(summary) == 1 and len(detail) == len(res)
    assert {"次日开盘%", "次日收盘%"} <= set(detail.columns)
